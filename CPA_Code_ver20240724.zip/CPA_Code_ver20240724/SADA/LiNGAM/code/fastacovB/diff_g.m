function y = diff_g( x )

y = 1 - tanh( x ) .^ 2;

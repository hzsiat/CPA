import argparse
import csv
import os
import numpy as np

def getNum(str, sourceStr):

    pos = sourceStr.find(str)
    string = (sourceStr[pos:])
    return float(string.split(' ')[1][:-1])

def read_log(file):
    result = {}
    result['fdr'] = []
    result['tpr'] = []
    result['fpr'] = []
    result['shd'] = []
    result['f1'] = []
    cnt = 0
    with open(file) as f:
        while True:
            lines = f.readline()
            if not lines:
                break
            if not (lines[0] >= '0' and lines[0] <= '9'):
                continue
            if 'fdr' in lines:
                cnt += 1
                result['fdr'].append(getNum('fdr',lines))
                result['tpr'].append(getNum('tpr',lines))
                result['fpr'].append(getNum('fpr',lines))
                result['shd'].append(getNum('shd',lines))
                if 'f1' in lines:
                    result['f1'].append(getNum('f1',lines))
                else:
                    tpr = getNum('tpr',lines)
                    fdr = getNum('fdr',lines)
                    if tpr == 0 or fdr == 1.0:
                        result['f1'].append(0.0)
                    else:
                        result['f1'].append(2*tpr*(1-fdr)/(1-fdr+tpr))
    print(cnt)
    return result

def getResult():
    # print('lambda_1:{}.lambda_3:{}'.format(l1, l3))
    result_mean = {}
    result_std = {}
    for seed in range(1, 6):
        file = r'output/non_equal_variances.seed:{}/training.log'.format(seed)
        result = read_log(file)
        for key in result.keys():
            if key not in result_mean.keys():
                result_mean[key] = []
            result_mean[key].append(result[key][0])
            
    for key in result.keys():
        result_std[key] = np.std(result_mean[key])
        result_mean[key] = np.mean(result_mean[key])
        # result_std[key] = np.std(result_mean[key])
    print('mean:',result_mean, 'std:',result_std)
    # flag = os.path.isfile(r'output_non_equal_SEMs/result.csv')
    # if flag==False:
    #     f = open('output_non_equal_SEMs/result.csv','w',encoding='utf-8')
    #     csv_writer = csv.writer(f)
    #     # csv_writer.writerow(['lambda_1','lambda_3','fdr','tpr','fpr','shd'])
    
    # f = open('output_non_equal_SEMs/result.csv','a+',encoding='utf-8')
    # csv_writer = csv.writer(f)
    # csv_writer.writerow(result)

def main():
    
    getResult()     


if __name__ == '__main__':
    main()
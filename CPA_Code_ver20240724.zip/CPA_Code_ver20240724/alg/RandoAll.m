function [cut_set,nodeA,nodeB,nodeCD]=RandoAll(X,r_s)
cut_set =[];
nodeCD =[];
r_s = [];
% r = randperm(size(X,2));
nodeA = 1:size(X,2);
nodeB = 1:size(X,2);
end

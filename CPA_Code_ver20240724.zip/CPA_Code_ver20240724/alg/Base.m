function [cut_set,nodeA,nodeB,nodeCD]=Base(X,r_s)
cut_set =[];
nodeCD =[];
r_s = [];
nodeA = 1:size(X,2);
nodeB = [];
end
